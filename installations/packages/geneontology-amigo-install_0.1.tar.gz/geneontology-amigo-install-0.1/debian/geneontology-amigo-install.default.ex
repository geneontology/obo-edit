# Defaults for geneontology-amigo-install initscript
# sourced by /etc/init.d/geneontology-amigo-install
# installed at /etc/default/geneontology-amigo-install by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
