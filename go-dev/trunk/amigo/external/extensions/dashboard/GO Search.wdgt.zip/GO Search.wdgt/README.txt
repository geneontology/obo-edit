## In the directory above:
zip -r GO\ Search.wdgt.zip  GO\ Search.wdgt/
